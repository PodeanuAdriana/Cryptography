#include <iostream>
#include<cmath>
using namespace std;

int main()
{
    int x,put,v[50],idx,kdx,ridic=0,multiplic=0;
    long int rez=1;
    //citesc numarul
    cin>>x;
    //citesc puterea la care ridic numarul
    cin>>put;

    //descompun puterea in binar si retin restul intr-un vector
    idx=0;
    while(put!=0)
    {
        v[idx]=put%2;
        put=put/2;
        idx++;

    }

    rez=rez*x;///pentru primul 1 din puterea binarului luam x
    for(kdx=0; kdx<=idx-1; kdx++)
        cout<<v[kdx]<<" ";
    cout<<endl;
     for(kdx=idx-1; kdx>=0; kdx--)
        cout<<v[kdx]<<" ";
    cout<<endl;

    for(kdx=idx-2; kdx>=0; kdx--) //merge parcurgerea inversa
    {

        if(v[kdx]==0)
        {
            rez=rez*rez;
            ridic++;
        }
        else if(v[kdx]==1)
        {
            rez=rez*rez*x;
            ridic++;
            multiplic++;
        }
    }
    cout<<rez<<endl;
    cout<<"Am ridicat la putere de: "<<ridic<<endl;
    cout<<"Am multiplicat de: "<<multiplic<<endl;
    return 0;
}

