#include <iostream>
#include<string.h>
#include<cstring>

using namespace std;
/// afin (ax+b)

///declarari
int idx,a,b,length,ascii[256],ascii_cifrat[256];
char text[256],text_cifrat[256],text_decifrat[256];
void citire()
{
    cout<<"Nr caracterelor: ";
    cin>>length;
    cout<<"Textul este: "<<endl;
    for(idx=0;idx<=length;idx++)
    {
        cin>>text[idx];
    }
    cout<<"a= ";
    cin>>a;
    cout<<endl<<"b= ";
    cin>>b;
}
void afisari()
{
    for(idx=0;idx<=length;idx++)
    {
        cout<<text[idx]<<" ";
    }
    cout<<endl;
     for(idx=0;idx<=length;idx++)
    {
        cout<<ascii[idx]<<" ";
    }
    cout<<endl;
     for(idx=0;idx<=length;idx++)
    {
        cout<<ascii_cifrat[idx]<<" ";
    }
    cout<<endl;
     for(idx=0;idx<=length;idx++)
    {
        cout<<text_cifrat[idx]<<" ";
    }
    cout<<endl;

         for(idx=0;idx<=length;idx++)
    {
        cout<<text_decifrat[idx]<<" ";
    }
    cout<<endl;

}
int main()
{
    ///ax+b
    citire();
    for(idx=0;idx<=length;idx++)
    {

        ascii[idx]=(int(text[idx])-97)%26;
        ///am transformat in ascii si am facut si modul 26

    }
    for(idx=0;idx<=length;idx++){
        ascii_cifrat[idx]=(ascii[idx]*a+b)%26;
        ///am incifrat textul cu ajutoul formulei si am facut %26 ca sa nu avem caractere speciale in cifrare
    }
    for(idx=0;idx<=length;idx++)
    {
        text_cifrat[idx]=char(ascii_cifrat[idx]+97);
    }
    ///decifrarea  textului

    for(idx=0;idx<=length;idx++)
    {
        text_decifrat[idx]=(text_cifrat[idx]-b)/a;
    }
    afisari();
    return 0;
}
