#include <iostream>
#include <string.h>
using namespace std;
int i,j,n;
int key[26];
char text_criptat[100],text_decriptat[100];


void citire()
{
    cout<<"Criptare:";
    cin.getline(text_criptat,100);
    n=strlen(text_criptat);
    for(i=0;i<26;i++)
        key[i]=i;
}


void atac()
{
    for(i=0;i<26;i++)
        {
            for(j=0;j<n;j++)
            {
                if(text_criptat[j]+key[i]<=122)
                    text_decriptat[j]=text_criptat[j]-key[i];
                else text_decriptat[j]=text_criptat[j]-key[i]-26;
            }

            cout<<text_decriptat<<endl;
        }
}
int main()
{

    citire();
    atac();
    return 0;
}
