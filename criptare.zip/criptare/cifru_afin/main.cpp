#include <iostream>

using namespace std;
///cifru afin
 int i,n,a,b,ascii[256],incifrat_keys[256],gcd,ss,tt,x,y;
 char text_clar[256],text_incifrat[256],text_decriptat[256];
void citiri(){
cout<<"Numarul de litere ale cuv: ";
    cin>>n;
    cout<<"Primul numar din cheie: ";
    cin>>a;
    cout<<"Al doilea numar din cheie: ";
    cin>>b;

    for(i=0;i<n;i++)
    {
        cin>>text_clar[i];
    }


}
 void transf_text_ascii()
 {
     int i;
     for(i=0;i<n;i++)
     {
         ascii[i]=(int(text_clar[i])-97)%26;

     }

 }
 void incifrare_afin()
{
    for(i=0;i<n;i++)
    {

        incifrat_keys[i]=(a*ascii[i]+b)%26;
    }


}
int  euclid_extins(int a, int b, int &gcd, int &s, int &t) {
    if (b== 0) {

        s = 1;
        t = 0;

        return a;
    }

    int gcd1, s1, t1;
    int result = euclid_extins(b, a % b, gcd1, s1, t1);

    gcd = gcd1;
    s = t1;
    t = s1 - (a / b) * t1;

 return result;

}
int  inversModular(int a){

 euclid_extins(a,26,gcd,ss,tt);



return ss%26;
}
void transf_text_incif()
{

    for(i=0;i<n;i++)
    {
        text_incifrat[i]=char(incifrat_keys[i]+97);

    }
}
void decriptare_affin()
 {
       for(i=0;i<n;i++)
       {
           text_decriptat[i]=(inversModular(a)*(int(text_incifrat[i]-97)-b)+26)%26+97;

       }

 }
void afisari()
{
    cout<<"Primul numar de cheie "<<a;
    cout<<"Al doilea numar de cheie"<<b;

    cout<<endl<<"Textul clar: "<<endl;
    for(i=0;i<n;i++)
    {
        cout<<text_clar[i]<<" ";
    }
    cout<<endl;
    cout<<"Transformarea textului in ASCII si mod 26: \n";
    for(i=0;i<n;i++)
    {
        cout<<ascii[i]<<" ";
    }
    cout<<endl;
    cout<<"Incifrarea coului ASCII cu cele doua numere a si b: \n";
    for(i=0;i<n;i++)
    {
        cout<<incifrat_keys[i]<<" ";
    }
    cout<<endl;
    cout<<"Transformarea textului  in caractere: \n";
    for(i=0;i<n;i++)
    {
        cout<<text_incifrat[i]<<" ";
    }
    cout<<endl;
    cout<<"Decriptarea textului cifrat: \n";
  // decriptare_affin();
    for(i=0;i<n;i++)
    {
        cout<<text_decriptat[i]<<" ";
   }

}





int main()
{

   citiri();

   transf_text_ascii();
   incifrare_afin();
   transf_text_incif();
   decriptare_affin();

   afisari();
    return 0;
}
