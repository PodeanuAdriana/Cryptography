#include <iostream>
#include<string.h>
#include<cstring>

using namespace std;


char text[256],text_cifrat[256],text_clar[256];
int key,idx,length,ascii[256],ascii1[256];

void citiri()
{
    cout<<"Lungimea cuvantului este: ";
    cin>>length;
    cout<<"citeste textul:";
    for(idx=0; idx<length; idx++)
    {

        cin>>text[idx];
    }


    cout<<"cheia este: ";
    cin>>key;


}
void afisari()
{

    for(idx=0; idx<length; idx++)
    {
        cout<<text[idx]<<" ";

    }
    cout<<endl;


    for(idx=0; idx<length; idx++)
    {
        cout<<ascii[idx]<<" ";

    }
    cout<<endl;


    for(idx=0; idx<length; idx++)
    {
        cout<<text_cifrat[idx]<<" ";

    }

    cout<<endl;

    for(idx=0; idx<length; idx++)
    {
        cout<<text_clar[idx]<<" ";

    }
    cout<<endl;

}
int main()
{
    citiri();

    for(idx=0; idx<length; idx++)
    {

        ascii[idx]=(text[idx]-97)%26;

    }

    for(idx=0; idx<length; idx++)
    {

        text_cifrat[idx]=ascii[idx]+key +97;

    }

    for(idx=0; idx<length; idx++)
    {

        text_clar[idx]=char(text_cifrat[idx]-key);
    }

    afisari();


    return 0;
}
