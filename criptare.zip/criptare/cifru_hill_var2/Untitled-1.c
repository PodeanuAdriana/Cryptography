#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

#define BUFFER_SIZE 5

// Shared buffer and semaphore
int buffer[BUFFER_SIZE];
sem_t empty; // Number of empty slots in the buffer
sem_t full;  // Number of filled slots in the buffer
pthread_mutex_t mutex; // Mutex to protect the buffer


void* producer(void* arg);
void* consumer(void* arg);

int main() {
    // Initialize semaphores and mutex
    sem_init(&empty, 0, BUFFER_SIZE);
    sem_init(&full, 0, 0);
    pthread_mutex_init(&mutex, NULL);

    
    pthread_t producerThread, consumerThread;

    
    if (pthread_create(&producerThread, NULL, producer, NULL) != 0) {
        perror("pthread_create (producer)");
        exit(EXIT_FAILURE);
    }

    
    if (pthread_create(&consumerThread, NULL, consumer, NULL) != 0) {
        perror("pthread_create (consumer)");
        exit(EXIT_FAILURE);
    }

    
    if (pthread_join(producerThread, NULL) != 0) {
        perror("pthread_join (producer)");
        exit(EXIT_FAILURE);
    }

    if (pthread_join(consumerThread, NULL) != 0) {
        perror("pthread_join (consumer)");
        exit(EXIT_FAILURE);
    }

    // Destroy semaphores and mutex
    sem_destroy(&empty);
    sem_destroy(&full);
    pthread_mutex_destroy(&mutex);

    return 0;
}

void* producer(void* arg) {
    for (int i = 0; i < 10; ++i) {
        // Produce item
        int item = i;

        // Wait for an empty slot
        sem_wait(&empty);

        // Acquire the mutex to access the buffer
        pthread_mutex_lock(&mutex);

        // Add item to the buffer
        buffer[i % BUFFER_SIZE] = item;
        printf("Produced: %d\n", item);

        // Release the mutex
        pthread_mutex_unlock(&mutex);

        // Signal that a slot is filled
        sem_post(&full);

        // Simulate some work
        sleep(1);
    }

    pthread_exit(NULL);
}

void* consumer(void* arg) {
    for (int i = 0; i < 10; ++i) {
        // Wait for a filled slot
        sem_wait(&full);

        // Acquire the mutex to access the buffer
        pthread_mutex_lock(&mutex);

        
        int item = buffer[i % BUFFER_SIZE];
        printf("Consumed: %d\n", item);

        // Release the mutex
        pthread_mutex_unlock(&mutex);

        // Signal that a slot is empty
        sem_post(&empty);

        sleep(1);
    }

    pthread_exit(NULL);
}