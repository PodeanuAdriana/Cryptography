#include <iostream>
#include<fstream>
#include<string.h>
using namespace std;
//declarari
char text_clar[50], text_cifrat[50][50],text_decifrat[50][50];
int matrice_crip[50][50],matrice_decrip[50][50],i,j,n,text_ascii[50],k,block[50][50],suma[50][50],suma_de[50][50];

ifstream f("matrice_crip.txt");
ifstream g("matrice_decrip.txt");
void citiri()
{
    cout<<"Textul clar este: ";
    cin.getline(text_clar,50);
    n=strlen(text_clar);

    for(i=0; i<3; i++)
    {
        for(j=0; j<3; j++)
        {
            f>>matrice_crip[i][j];
        }
    }
    for(i=0; i<3; i++)
    {
        for(j=0; j<3; j++)
        {
            g>>matrice_decrip[i][j];
        }
    }
}
void transformare_text()
{
    for(i=0; i<n; i++)
    {
        text_ascii[i]=(int(text_clar[i])-97) %26;
    }
}
void bloc_text()
{
    i=0;
    for(k=0; k<n/3+n%3; k++)
    {
        j=0;
        while(j<3)
        {
            if(i<=n-1)
            {
                block[k][j]=text_ascii[i];
                i++;
            }
            else
                block[k][j]=1446;
            j++;
        }
    }
}

void inmultire_matrice()
{

    for(i=0; i<3; i++)
    {
        for(i=0; i<3; i++)
        {
            suma[i][j]=0;
           // cout<<suma[i][k]<<" ";
        }
        //cout<<endl;
    }
    for(i=0;i<3;i++)
    {
        for(k=0;k<3;k++)
        {

            suma[i][k]+=block[i][k]*matrice_crip[k][i];
            //cout<<suma[i][k]<<" ";
        }
    }


}
void cifrare_text()
{
    for(i=0; i<3; i++)
    {
        for(j=0; j<3; j++)
        {

            text_cifrat[i][j]=char(suma[i][j]+97);///trebuie sa gandesc cum elimin restul de 1,2 poz din matrice
        }
    }
}
/*void decriptare_text()
{
        for(i=1; i<=3; i++)
    {
        for(i=1; i<=3; i++)
        {
            suma_de[i][j]=0;
        }
    }

    for(i=1; i<=3; i++)
        {
        for(j=1; j<=3; j++)
        {
            suma_de[i][j]=(suma_de[i][j]+text_cifrat[i][j]*matrice_decrip[j][i])%26;///trebuie sa vad daca da corect la inmultire
        }
        }

}
void text_decrip()
{
      for(i=1;i<=3;i++)
    {
        for(j=1;j<=3;j++)
        {

            text_decifrat[i][j]=char(suma_de[i][j]+97);///trebuie sa gandesc cum elimin restul de 1,2 poz din matrice
            cout<<text_decifrat[i][j]<<" ";
        }
        cout<<endl;
    }

}*/

void afisari()
{
    cout<<"Textul clar este: "<<text_clar;
    cout<<endl;
    cout<<"Matricea de criptare este: "<<endl;
    for(i=0; i<3; i++)
    {
        for(j=0; j<3; j++)
        {
            cout<<matrice_crip[i][j]<<" ";
        }
        cout<<endl;
    }
    cout<<endl<<"Matricea de decriptare este: "<<endl;
    for(i=0; i<3; i++)
    {
        for(j=0; j<3; j++)
        {
            cout<<matrice_crip[i][j]<<" ";
        }
        cout<<endl;
    }
    cout<<endl<<"Text clar in ascii transformat :"<<endl;

    for(i=0; i<n; i++)
    {
        cout<<text_ascii[i]<<" ";
    }
    cout<<endl<<"Pus in bloc: "<<endl;
    for(k=0; k<=n/3+n%3; k++)
    {
        for(j=0; j<3; j++)
            cout<<block[k][j]<<" ";
        cout<<endl;
    }
    cout<<endl;
    cout<<"Inmultirea blocurilor: "<<endl;
    for(i=0; i<3; i++)
    {
        for(j=0; j<3; j++)
        {
            cout<<suma[i][j]<<" ";
        }
        cout<<endl;
    }
    cout<<endl<<"Criptarea mesajului: "<<endl;
    for(i=0; i<3; i++)
    {
        for(j=0; j<3; j++)
        {
            cout<<text_cifrat[i][j]<<" ";
        }
        cout<<endl;
    }
    cout<<endl<<"Decriptarea mesajului: "<<endl;
    for(i=0; i<3; i++)
    {
        for(j=0; j<3; j++)
        {
            cout<<suma_de[i][j]<<" ";
        }
        cout<<endl;
    }
    cout<<endl<<"Decriptarea mesajului in litere: "<<endl;
    for(i=0; i<3; i++)
    {
        for(j=0; j<3; j++)
        {
            cout<<text_decifrat[i][j]<<" ";
        }
        cout<<endl;
    }

}



int main()
{
    citiri();
    transformare_text();
    bloc_text();
    inmultire_matrice();
    cifrare_text();
//    decriptare_text();
    // text_decrip();
    afisari();


    return 0;
}
