#include <iostream>
#include <cstring>
#include <string.h>
using namespace std;

///Vingere litere

char text_clar[50],keys[50],cifrare_text[50],decriptat[50];
int n,k,j,i,ascii_text_clar[50],ascii_cheie[50];

void citiri()
{
    cout<<"Text clar ";
    cin.getline(text_clar,50);

    cout<<"Cheia este: ";
    cin.getline(keys,50);

}
void prelucrare_vector_cheie()
{
    n=strlen(text_clar);
    k=strlen(keys);
    int j=0;
    for(i=k; i<n; i++)
    {
        keys[i]=keys[j];
        j++;
        if(j>=k)
        {
            j=0;
        }

    }

}

void prelucrare_text_clar()
{
    for(i=0; i<n; i++)
    {
        ascii_text_clar[i]=((text_clar[i])-97)%26;
        ascii_cheie[i]=((keys[i])-97)%26;
    }

}
void cifrare_text_clar()
{
    for(j=0; j<n; j++)
    {
        cifrare_text[j]=char((ascii_text_clar[j]+ascii_cheie[j])%26+97);
    }

}

void decriptare_text_clar()
{
    for(j=0; j<n; j++)
    {
        decriptat[j]=char((cifrare_text[j]-keys[j])%26+97);
        if((int)decriptat[j]<97)
            decriptat[j]+=26;
        ///m -------> S
        ///109------->83
        /// t--------->O
        ///116-------->79

        /// rezolvat problema;)


    }
}

    void afisari()
    {
        ///textul clar
        for(i=0; i<n; i++)
        {
            cout<<text_clar[i]<<" ";
        }
        cout<<endl;
        for(i=0; i<n; i++)
        {
            cout<<(int)text_clar[i]<<" ";
        }
        cout<<endl;
        ///vectorul cheie
        for(j=0; j<n; j++)
            cout<<keys[j]<<" ";
        cout<<endl;
        ///prelucrare ascii mesaj+cheie
        for(i=0; i<n; i++)
        {
            cout<<ascii_text_clar[i]<<" ";
        }
        cout<<endl;
        for(i=0; i<n; i++)
        {
            cout<<ascii_cheie[i]<<" ";
        }
        cout<<endl;
        ///decriptarea
        for(i=0; i<n; i++)
        {
            cout<<(int)decriptat[i]<<" ";
        }
        cout<<endl;
        for(i=0; i<n; i++)
        {
            cout<<decriptat[i]<<" ";
        }
    }

int main()
{
    citiri();
    prelucrare_text_clar();
    cout<<endl;
    prelucrare_vector_cheie();
    cout<<endl;
    prelucrare_text_clar();
    cout<<endl;
    cifrare_text_clar();
    cout<<endl;
    decriptare_text_clar();
    cout<<endl;
    afisari();
    return 0;
}
