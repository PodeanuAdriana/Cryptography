#include <iostream>
#include <string.h>
using namespace std;

int main()
{
    char text_clar[20];
    int n,i;

    cout<<"Citeste cuvantul: ";
    cin.getline(text_clar,20);
    cout<<text_clar<<endl;
    n=strlen(text_clar);
    for(i=0;i<n;i++)
        cout<<"text_clar["<<i<<"]="<<text_clar[i]<<endl;
    return 0;
}
