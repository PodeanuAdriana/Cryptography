#include <iostream>

using namespace std;

int main()
{   int n,m,r=0;
    cin>>n;
    cin>>m;
    //euclid prin scadere

   /* while(n!=m)
    {
        if(n>m)
            {n=n-m;
            cout<<"n= "<<n<<endl;}

        else
           {m=m-n;
           cout<<"m= "<<m<<endl;

           }


    }
    cout<<"CMMDC este: "<<n;
*/
    // euclid prin impartire

   while (m!=0)
    {

     r=n%m;
     cout<<"r= "<<r<<endl;
     n=m;
     cout<<"n= "<<n<<endl;
     m=r;
     cout<<"m= "<<m<<endl;
    }
     cout<<"CMMDC este: "<<n;

    return 0;
}
