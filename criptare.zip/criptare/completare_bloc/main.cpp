#include <iostream>

using namespace std;

int main()
{
   ///citesc textul sau un sir de numere lung
   ///123456789
   int n,i,nr_bl,block[][],j;
   cin>>n;
   for(i=1;i<9)
    return 0;
}
