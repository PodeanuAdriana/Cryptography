#include <iostream>
//descompunerea in factori primi
using namespace std;

int main()
{
    //citesc numarul
    int nr,div=2,putere;
    cin>>nr;

    while(nr>1)
    {
        putere=0;

        while(nr%div==0)
        {
            nr=nr/div;
            putere=putere+1;

        }

        if(putere!=0)
                cout<<div<<"la puterea "<<putere<<endl;
        div++;



    }
    return 0;
}
