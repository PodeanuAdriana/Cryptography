#include <iostream>
using namespace std;

int euclid_extins(int a, int b, int &gcd, int &s, int &t) {
    if (b == 0) {
        gcd = a;
        s = 1;
        t = 0;
        return 0;
    }

    int gcd1, s1, t1;
    int result = euclid_extins(b, a % b, gcd1, s1, t1);

    gcd = gcd1;
    s = t1;
    t = s1 - (a / b) * t1;

    return result;
}

int main() {
    int a, b, gcd, s, t;
    cout << "a= ";
  cin >> a ;
  cout<<"b= ";
  cin>> b;

    int result = euclid_extins(a, b, gcd, s, t);

    if (result == 0) {
        cout << "GCD al lui " << a << " si " << b << " este " << gcd << endl;
        cout<<endl;
        cout << "Ecuatia: " << a << " * x + " << b << " * y = " << gcd <<endl;
        cout<< " x = " << s <<endl;
        cout<< " y = " << t << endl;
    }

    return 0;
}
