#include <iostream>
#include <string.h>
#include<cstring>
#include<fstream>

///CIFRU HILL

using namespace std;
ifstream f("matrice_crip.txt");
ifstream g("matrice_decrip.txt");

char text_clar[50];
int j,i,k,matrice_criptare[20][20], matrice_decriptare[20][20],suma[50],n,text_ascii[50],block[50][50],x,h,diff;

void citiri()
{
    ///citesc textul clar
    cout<<"Citeste cuvantul: ";
    cin.getline(text_clar,50);
    n=strlen(text_clar);
    ///citesc matricea de criptare din fisier
    for(i=1; i<=3; i++)
    {
        for(j=1; j<=3; j++)
        {
            f>>matrice_criptare[i][j];
        }

    }
    ///citesc matrice de decriptare din fisier

    for(i=1; i<=3; i++)
    {
        for(j=1; j<=3; j++)
        {

            g>>matrice_decriptare[i][j];
        }
    }
}
/*void impartire_blocuri()
{
                                    ///impart textul clar in block de lungime 3  textul clar
    for(i=0; i<n; i++)
    {
        for(j=)
        }

}*/
void transformare_text()
{
    for(i=0; i<n; i++)
        text_ascii[i]=(int(text_clar[i])-97) %26;
    for(i=0;i<n;i++)
        cout<<text_ascii[i];
}
void impartire_blocuri()
{
        i=0;///plec cu primul caracter al textului ascii
        j=0;///prima coloana din ascii ce trebuie completata
        nr_blc=0;///nr_blocuri
        while(j<=2)
        {
            block[nr_blc][j]=text_ascii[i];
            i++;
            j++;
            if(j==2)
            {
                nr_blc++;
                j=0;
            }
            if(nr_blc==n/3 && i<=n-2)///daca nu sa ajuns la finalul textului si nr_blocuri complete s-a facut atunci
            {
                nr_bloc++;
                block[nr_block][j]=text_ascii[i];
                i++;
            }

        }
        for()

}
/*void impartire_blocuri()
{
    int h,x,diff;

    i=0;
    for(k=1; k<=3; k++)
    {

        for(j=1; j<=3; j++)                     /// matrice bloc si pun litera in functie de litera din textul clar
        {
            block[k][j]=text_ascii[i];
            i++;
        }                                ///daca textul este de lungime 2

    }

    ///daca a mai ramas text dupa cele 3 blocuri completate
    if(i<n)
    {
        x=i;                            ///pasul la care litera a ramas pe din afara
        diff=n-i;                       ///cate litere mai am de adaugat
        k=4;                            ///blocul care a ramas de completat
        for(h=1; h<=diff; h++)
        {
            block[k][h]=text_ascii[i];
        }                               /// completez diferenta de litere care a ramas
        for(h=diff; diff<n; i++)
        {
            block[k][h]=0;              ///pun 0 unde nu am litera
        }
    }


}*/

void inmultire_matrice()
{
    for(i=1; i<=3; i++)

        for(j=1; j<=3; j++)

        {
            suma[j]=(suma[j]+block[i][j]*matrice_criptare[j][i])%26;
        }
    for(i=1; i<=3; i++)
        cout<<suma[i]<<" ";
}
void afisari()
{
    cout<<"Mesajul este: ";
    cout<<text_clar;
    cout<<endl;
    cout<<"Matrice criptare: ";
    cout<<endl;
    for(i=1; i<=3; i++)
    {
        for(j=1; j<=3; j++)
        {
            cout<<matrice_criptare[i][j]<<" ";
        }
        cout<<endl;
    }
    cout<<endl;
    cout<<"Matrice decriptare: ";
    cout<<endl;
    for(i=1; i<=3; i++)
    {
        for(j=1; j<=3; j++)
        {
            cout<<matrice_decriptare[i][j]<<" ";
        }
        cout<<endl;
    }

}
int main()
{
    citiri();
    transformare_text();
    //afisari();
   // inmultire_matrice();
    return 0;
}
