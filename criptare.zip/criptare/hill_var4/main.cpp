#include <iostream>
#include <fstream>
#include <string.h>

using namespace std;

ifstream f("matrice_criptare.txt");
ifstream g("matrice_decriptare.txt");

char text_clar[50], text_cifrat[50][50], text_decifrat[50][50];
int matrice_crip[3][3], matrice_decrip[3][3], i, j, n, text_ascii[50], k, block[50][50], c[50][50], b[50][50], n2, n1, m, p, d[50][50],text_decriptat[50][50];
int suma[50][50];

void citiri()
{
    cout << "Textul clar este: ";
    cin.getline(text_clar, 50);
    n = strlen(text_clar);

    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            f >> matrice_crip[i][j];
        }
    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            g >> matrice_decrip[i][j];
        }
    }
}
void transformare_text()
{
    for (i = 0; i < n; i++)
    {
        text_ascii[i] = (int(text_clar[i]) - 97) % 26;
    }
}
void bloc_text()
{
    i = 0;
    for (k = 0; k < n / 3 + n % 3; k++)
    {
        j = 0;
        while (j < 3)
        {
            if (i <= n - 1)
            {
                block[k][j] = text_ascii[i];
                i++;
            }
            else
                block[k][j] = -1;
            j++;
        }
    }
}
void inmultire_matrice_crip()
{
    // recitesc matricea pusa in bloc de la tastatura
    // nr de lini cu nr de coloane
    n2 = n / 3 + 2; // cout<<n2;
    p = m = 3;
    for (i = 0; i < m; i++)
        for (j = 0; j < p; j++)
            c[i][j] = 0;
    for (i = 0; i < m; i++)
        for (j = 0; j < p; j++)
            for (k = 0; k < n2; k++)
                c[i][j] += matrice_crip[i][k] * block[k][j];


}
void inmultire_matrice_decrip()
{
    // recitesc matricea pusa in bloc de la tastatura
    // nr de lini cu nr de coloane
    n2 = n / 3 + 2; // cout<<n2;
    p = m = 3;
    for (i = 0; i < m; i++)
        for (j = 0; j < p; j++)
            d[i][j] = 0;
    for (i = 0; i < m; i++)
        for (j = 0; j < p; j++)
            for (k = 0; k < n2; k++)
                d[i][j] += matrice_decrip[i][k] * c[k][j];

 cout << "DECriptarea mesajului: " << endl;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            //text_decriptat[i][j] = char(d[i][j] % 26 + 97);
            cout << d[i][j] %26<< " ";
        }
        cout << endl;
    }
}

void afisari()
{
    cout << "Textul clar este: " << text_clar;
    cout << endl;
    cout << "Matricea de criptare este: " << endl;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            cout << matrice_crip[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl
         << "Matricea de decriptare este: " << endl;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            cout << matrice_decrip[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl
         << "Text clar in ascii transformat :" << endl;

    for (i = 0; i < n; i++)
    {
        cout << text_ascii[i] << " ";
    }
    cout << endl;
    cout << endl
         << "Pus in bloc: " << endl;
    for (k = 0; k <= n / 3 + n % 3; k++)
    {
        for (j = 0; j < 3; j++)
            cout << block[k][j] << " ";
        cout << endl;
    }
    cout << endl;

      cout << "Inmultirea blocurilor: " << endl;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            cout << c[i][j] % 26 << " ";
        }
        cout << endl;
    }
    cout << endl;

    cout << "Criptarea mesajului: " << endl;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            text_cifrat[i][j] = char(c[i][j] % 26 + 97);
            cout << text_cifrat[i][j] << " ";
        }
        cout << endl;
    }
}

int main()
{
    citiri();
    transformare_text();
    bloc_text();
    inmultire_matrice_crip();
    inmultire_matrice_decrip();
    afisari();

    return 0;
}
