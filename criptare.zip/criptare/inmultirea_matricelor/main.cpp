#include<iostream>
using namespace std;
int main()
{
    int a[10][10],b[10][10],c[10][10],i,j,k,m,n1,n2,p;
    cout<<"Introduceti dimensiunile celor doua matrici si elementelelor"<<endl;
        cout<<"Matricea A : "<<endl;
    cout<<"numarul de linii : ";
    cin>>m;
    cout<<"numarul de coloane : ";
    cin>>n1;
    for(i=0; i<m; i++)
        for(j=0; j<n1; j++)
        {
            cout<<"a["<<i+1<<","<<j+1<<"]=";
            cin>>a[i][j];
        }
    cout<<"Matricea B : "<<endl;
    do
    {
        cout<<"numarul de linii : ";
        cin>>n2;
    }
    while(n2!=n1);
    cout<<"numarul de coloane : ";
    cin>>p;
    for(i=0; i<n2; i++)
        for(j=0; j<p; j++)
        {
            cout<<"b["<<i+1<<","<<j+1<<"]=";
            cin>>b[i][j];
        }
    for(i=0; i<m; i++)
        for(j=0; j<p; j++)
            c[i][j]=0;
    for(i=0; i<m; i++)
        for(j=0; j<p; j++)
            for(k=0; k<n1; k++)
                c[i][j]+=a[i][k]*b[k][j];
    cout<<"Matricea produs este :"<<endl;
    for(i=0; i<m; i++)
    {
        for(j=0; j<p; j++)
            cout<<c[i][j]%26<<" ";
        cout<<endl;
    }
    cout<<endl;
    return 0;
}

