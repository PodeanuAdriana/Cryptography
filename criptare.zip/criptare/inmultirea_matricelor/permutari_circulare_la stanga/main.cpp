#include <iostream>

using namespace std;
int n,i,v[1000],k,x;

int main()
{
    cin>>n;
    for(i=1;i<=n;i++)
    cin>>v[i];
for(k=1;k<=n;k++)
{
    x=v[i];
    for(i=2;i<=n;i++)
        v[i-1]=v[i];
    v[n]=x;
    for(i=1;i<=n;i++)
        cout<<v[i]<<" ";
    cout<<endl;
}

    return 0;
}
