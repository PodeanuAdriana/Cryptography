#include <iostream>
#include<string.h>
using namespace std;
char alphabet[]="abcdefghijklmnopqrstuvwxyz";
     char key[]="zyxwvutsrqponmlkjihgfedcba";
     char text_clar[50];
     char x,cifrare_text[50],decriptare_text[50];
     int m,n,i,k;
int main()
{

         cin.getline(text_clar,50);
         n=strlen(text_clar);
         m=strlen(alphabet);
         for(i=0;i<n;i++)
            for(k=0;k<m;k++)
            {
                if(text_clar[i]==alphabet[k])
                    cifrare_text[i]=key[k];
            }
        for(i=0;i<n;i++)
            for(k=0;k<m;k++)
            {
                if(cifrare_text[i]==key[k])
                    decriptare_text[i]=alphabet[k];
            }
    cout<<cifrare_text;
    cout<<endl;
    cout<<decriptare_text;
    return 0;
}
