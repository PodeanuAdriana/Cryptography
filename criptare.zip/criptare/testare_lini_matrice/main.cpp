#include <iostream>
#include <fstream>
ifstream f("matrice.in");
using namespace std;
int idx,jdx,kdx,scor,combo,aux,matrice[100][100],cp,nr_lini;
void citire_matrice()
{

    for(idx=0; idx<nr_lini; idx++)
    {
        for(jdx=0; jdx<nr_lini; jdx++)
        {
            f>>matrice[idx][jdx];//am citit elementele din matrice
        }
    }


}
void afisare_matrice()
{

    for(idx=0; idx<nr_lini; idx++)
    {
        for(jdx=0; jdx<nr_lini; jdx++)
        {
            cout<<matrice[idx][jdx]<<" ";//am afisat elementele din matrice
        }
        cout<<endl;
    }


}
void testare_linii()
{



}
int main()
{
    f>>nr_lini;
    citire_matrice();
    afisare_matrice();
    interschimbare_elem();
    copiere_elemente();
    randomizare_elem();
    testare_lini();
    return 0;
}
